package com.gov.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.InstituteRegisterDao;
import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;

@Service
public class InstituteRegisterServiceImpl implements InstituteRegisterService {
	@Autowired
	InstituteRegisterDao dao;
	@Transactional
	public boolean addInstitute(InstituteRegister instituteregister) {
		int result=dao.createInstitute(instituteregister);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}
	
	
	public List<InstituteMaster> checkAllInstituteDetails() {
		List<InstituteMaster> list = dao.readAllInstituteDetails();
		if(list!=null)
		{
			return list;
		}else{
			return null;	
		}
		
	}

}
