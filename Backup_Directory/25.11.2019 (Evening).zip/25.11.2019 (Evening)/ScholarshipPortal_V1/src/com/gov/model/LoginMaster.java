package com.gov.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="LOGIN_MASTER")
public class LoginMaster implements Serializable{
	@Id
	@Column(name="USERNAME")
	private String user_name;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="ROLE")
	private String role;
	@Column(name="EMAIL")
	private String email;
	
	public LoginMaster() {
	}

	public LoginMaster(String user_name, String password, String role, String email) {
		super();
		this.user_name = user_name;
		this.password = password;
		this.role = role;
		this.email = email;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return "LoginMaster [user_name=" + user_name + ", password=" + password + ", role=" + role + ", email=" + email
				+ "]";
	}
	
	
	
	

}
