package com.gov.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="STUDENT_REGISTER")
@SequenceGenerator(name="stud_seq", sequenceName="stud_seq" , initialValue=1, allocationSize=1)
public class StudentRegister implements Serializable{
	
	@Column(name="AADHAR_NUMBER")
	private String aadhar_number;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="stud_seq")
	@Column(name="STUDENT_ID")
	private int student_id;
	@Column(name="STUDENT_NAME")
	private String student_name;
	@Column(name="DATE_OF_BIRTH")
	private Date date_of_birth;
	@Column(name="GENDER")
	private String gender;
	@Column(name="MOBILE_NUMBER")
	private String mobile_number;
	@Column(name="EMAIL")
	private String email;
	@Column(name="DOMICILE_STATE")
	private String domicile_state;
	@Column(name="DISTRICT")
	private String district;
	@Column(name="BANK_NAME")
	private String bank_name;
	@Column(name="BANK_ACCOUNT_NUMBER")
	private String bank_account_number;
	@Column(name="IFSC_CODE")
	private String ifsc_code;
	
	public StudentRegister() {
		super();
	}

	public StudentRegister(String aadhar_number, String student_name, Date date_of_birth,
			String gender, String mobile_number, String email, String domicile_state, String district, String bank_name,
			String bank_account_number, String ifsc_code) {
		super();
		this.aadhar_number = aadhar_number;
		this.student_name = student_name;
		this.date_of_birth = date_of_birth;
		this.gender = gender;
		this.mobile_number = mobile_number;
		this.email = email;
		this.domicile_state = domicile_state;
		this.district = district;
		this.bank_name = bank_name;
		this.bank_account_number = bank_account_number;
		this.ifsc_code = ifsc_code;
	}

	public String getAadhar_number() {
		return aadhar_number;
	}

	public void setAadhar_number(String aadhar_number) {
		this.aadhar_number = aadhar_number;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomicile_state() {
		return domicile_state;
	}

	public void setDomicile_state(String domicile_state) {
		this.domicile_state = domicile_state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getBank_account_number() {
		return bank_account_number;
	}

	public void setBank_account_number(String bank_account_number) {
		this.bank_account_number = bank_account_number;
	}

	public String getIfsc_code() {
		return ifsc_code;
	}

	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}

	public String toString() {
		return "StudentRegister [aadhar_number=" + aadhar_number + ", student_id=" + student_id + ", student_name="
				+ student_name + ", date_of_birth=" + date_of_birth + ", gender=" + gender + ", mobile_number="
				+ mobile_number + ", email=" + email + ", domicile_state=" + domicile_state + ", district=" + district
				+ ", bank_name=" + bank_name + ", bank_account_number=" + bank_account_number + ", ifsc_code="
				+ ifsc_code + "]";
	}
	
	
	

}
