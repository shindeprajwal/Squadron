package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gov.model.InstituteRegister;
import com.gov.model.StudentDocs;

@Repository
public class StudentDocsDaoImpl implements StudentDocsDao{

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Transactional
	public int createStudentDocs(StudentDocs docs) {
		entitymanager.clear();
		entitymanager.merge(docs);
		return 1;
	}

	public List<StudentDocs> readDocumentByStudentId(int student_id) {
		TypedQuery<StudentDocs> query = entitymanager.createQuery("Select d from StudentDocs d where d.student_id="+student_id+"",StudentDocs.class);
		List<StudentDocs> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}
	
	@Transactional
	public int insertBonafideCertificate(int student_id,String bonafide_cert) {
		Query query = entitymanager.createQuery("Update StudentDocs d set d.bonafide_cert='"+bonafide_cert+"' where d.student_id="+student_id+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
	}

}
