package com.gov.dao;

import com.gov.model.AadharMaster;

public interface AadharMasterDao {

	public AadharMaster readAadhar(String aadhar_number);
	
}
