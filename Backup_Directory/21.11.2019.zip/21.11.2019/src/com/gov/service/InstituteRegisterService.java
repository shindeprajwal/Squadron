package com.gov.service;

import java.util.List;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;

public interface InstituteRegisterService {
	
	public boolean addInstitute(InstituteRegister instituteregister);
	
	public List<InstituteMaster> checkAllInstituteDetails();

}
