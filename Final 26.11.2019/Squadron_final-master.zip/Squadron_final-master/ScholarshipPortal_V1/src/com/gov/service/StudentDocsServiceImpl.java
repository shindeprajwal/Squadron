package com.gov.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.StudentDocsDao;
import com.gov.model.StudentDocs;

@Service
public class StudentDocsServiceImpl implements StudentDocsService{

	@Autowired
	StudentDocsDao dao;
	
	public boolean addStudentDocs(StudentDocs docs) {
		int result = dao.createStudentDocs(docs);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}
	
	@Transactional
	public List<StudentDocs> findDocumentByStudentId(int student_id) {
		List<StudentDocs> list = dao.readDocumentByStudentId(student_id);
		if(list!=null)
		{
			return list;
		}else{
			return null;
		}
	}

	@Transactional
	public boolean updateBonafideCert(int student_id, String bonafide_cert) {
		int result= dao.insertBonafideCertificate(student_id, bonafide_cert);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}

}
