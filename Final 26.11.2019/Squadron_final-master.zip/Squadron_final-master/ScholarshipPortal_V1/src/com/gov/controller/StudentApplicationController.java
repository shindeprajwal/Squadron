package com.gov.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.gov.model.StudentApplication;
import com.gov.model.StudentDocs;
import com.gov.service.StudentApplicationService;
import com.gov.service.StudentDocsService;

@Controller
public class StudentApplicationController {

	@Autowired
	StudentApplicationService studentApplicationService;

	@Autowired
	StudentApplication studentApplication;
	
	@Autowired
	StudentDocs studentDocs;
	
	@Autowired
	StudentDocsService studentDocsService;
	
	private HttpSession session;

	@RequestMapping(path="addStudentApplication")
	public String addStudentApplicationPage() 
	{ 
		return "STUDENT_APPLICATION"; 
	}

	@RequestMapping(path="addStudentApplication.do",method=RequestMethod.POST)
	public String addStudentApplication(StudentApplication studentApplication,
			@RequestParam("student_photograph") MultipartFile student_photograph ,
			@RequestParam("domicile_certificate") MultipartFile domicile_certificate,
			@RequestParam("institute_id_card") MultipartFile institute_id_card,
			@RequestParam("caste_certificate") MultipartFile caste_certificate,
			@RequestParam("income_certificate") MultipartFile income_certificate,
			@RequestParam("previous_year_marksheet") MultipartFile previous_year_marksheet,
			@RequestParam("fee_receipt") MultipartFile fee_receipt,
			@RequestParam("bank_passbook") MultipartFile bank_passbook,
			@RequestParam("aadhar_card") MultipartFile aadhar_card,
			@RequestParam("marksheet") MultipartFile marksheet)
	{
		String rootPath = "D:/Student_Application"; //change path
		String student_photo  = rootPath+"/"+student_photograph.getOriginalFilename();
		String domicile_cert = rootPath+"/"+domicile_certificate.getOriginalFilename();
		String inst_id_card = rootPath+"/"+institute_id_card.getOriginalFilename();
		String caste_cert = rootPath+"/"+caste_certificate.getOriginalFilename();
		String income_cert = rootPath+"/"+income_certificate.getOriginalFilename();
		String previous_marksheet = rootPath+"/"+previous_year_marksheet.getOriginalFilename();
		String fee_rcpt = rootPath+"/"+fee_receipt.getOriginalFilename();
		String bank_pass = rootPath+"/"+bank_passbook.getOriginalFilename();
		String aadhar = rootPath+"/"+aadhar_card.getOriginalFilename();
		String  mark_sheet = rootPath+"/"+marksheet.getOriginalFilename();
		/*File dir1 = new File( rootPath + File.separator +  institute_code);*/
			try {
				
				student_photograph.transferTo(new File(student_photo));
				domicile_certificate.transferTo(new File(domicile_cert));
				institute_id_card.transferTo(new File(inst_id_card));
				caste_certificate.transferTo(new File(caste_cert));
				income_certificate.transferTo(new File(income_cert));
				previous_year_marksheet.transferTo(new File(previous_marksheet));
				fee_receipt.transferTo(new File(fee_rcpt));
				bank_passbook.transferTo(new File(bank_pass));
				aadhar_card.transferTo(new File(aadhar));
				marksheet.transferTo(new File(mark_sheet));
				
			} catch (IOException e) {
				System.out.println("Failed to upload file" +e);
			}
		int stud_id = studentApplication.getStudent_id();
		studentDocs.setAadhar(aadhar);
		studentDocs.setStudent_id(stud_id);
		studentDocs.setBank_pass(bank_pass);
		studentDocs.setCaste_cert(caste_cert);
		studentDocs.setDomicile_cert(domicile_cert);
		studentDocs.setFee_rcpt(fee_rcpt);
		studentDocs.setIncome_cert(income_cert);
		studentDocs.setInst_id_card(inst_id_card);
		studentDocs.setMark_sheet(mark_sheet);
		studentDocs.setPrevious_marksheet(previous_marksheet);
		studentDocs.setStudent_photo(student_photo);
		studentApplication.setStatus("Ongoing"); //New Git creds
		boolean result= studentApplicationService.addApplication(studentApplication);
		boolean result1 = studentDocsService.addStudentDocs(studentDocs);
		if(result&&result1) 
		{ 
			return "redirect:studentHome"; 
		} else
		{ 
			return "ERROR"; 
		} 
	}
	
	@RequestMapping(path="studentApplicationRedirect",method=RequestMethod.GET)
	public String studentApplicationView(Model model,@RequestParam("student_id") int stud_id)
	{
		List<StudentDocs> list = studentDocsService.findDocumentByStudentId(stud_id);
		model.addAttribute("docs_list", list);
		return "STUDENT_APPLICATION_VIEW";
	}
	
	  @RequestMapping(path="ministerStudentApplicationRedirect",method=
			  RequestMethod.GET) public String ministerStudentApplicationView(Model
			  model,@RequestParam("student_id") int stud_id) { List<StudentDocs> list =
			  studentDocsService.findDocumentByStudentId(stud_id);
			  model.addAttribute("docs_list", list);
			  
			  return "MINISTER_STUDENT_VIEW"; }
	
	@RequestMapping(path="studentApplicationRedirectNodal",method=RequestMethod.GET)
	public String studentApplicationView1(Model model)
	{
		List<StudentApplication> list = studentApplicationService.findApplicationByStatus();
		model.addAttribute("application_list", list);
		return "NODAL_APPLICATION_VIEW";
	}
	
	@RequestMapping(path="studentApplicationTableNodal",method=RequestMethod.GET)
	public String studentApplicationView2(Model model)
	{
		List<StudentApplication> list = studentApplicationService.findApplicationByStatus();
		model.addAttribute("application_list", list);
		return "NODAL_TABLE_VIEW";
	}
	
	@RequestMapping(path="acceptStudentApplication.do" , method=RequestMethod.POST)
	public String acceptStudentApplication(@RequestParam("bonafide_certificate") MultipartFile bonafide_certificate,
										   @RequestParam("app_id") int app_id,
										   @RequestParam("student_id") int student_id){
		String rootPath = "D:/Student_Application";
		String  bonafide_cert = rootPath+"/"+bonafide_certificate.getOriginalFilename();
		try{
			bonafide_certificate.transferTo(new File(bonafide_cert));
		}catch (IOException e) {
			System.out.println("Failed to upload file" +e);
		}
		boolean result = studentDocsService.updateBonafideCert(student_id, bonafide_cert);
		boolean result1 = studentApplicationService.approveStatus(app_id);
		if(result&&result1){
			return "redirect:instituteHome";
		}else{
		return "ERROR";
		}
	}
	
	@RequestMapping(path="rejectStudentApplication.do", method=RequestMethod.POST)
	public String rejectStudentApplication(@RequestParam("app_id") int app_id){
		boolean result = studentApplicationService.removeStatus(app_id);
		if(result){
			return "redirect:instituteHome";
		}else{
			return "ERROR";
			}
	}
	
	@RequestMapping(path="grantNodal.do", method=RequestMethod.GET)
	public String grantApplicationNodal(@RequestParam("app_id") int app_id)
	{
		boolean result = studentApplicationService.approveStatusNodal(app_id);
		if(result){
			return "redirect:nodalHome";
		}else{
			return "ERROR";
			}
	}
	
	@RequestMapping(path="rejectNodal.do", method=RequestMethod.GET)
	public String rejectApplicationNodal(@RequestParam("app_id") int app_id)
	{
		boolean result = studentApplicationService.removeStatusNodal(app_id);
		if(result){
			return "redirect:nodalHome";
		}else{
			return "ERROR";
			}
	}
	
}
