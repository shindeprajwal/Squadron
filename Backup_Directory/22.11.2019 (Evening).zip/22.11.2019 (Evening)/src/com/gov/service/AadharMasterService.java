package com.gov.service;

import com.gov.model.AadharMaster;

public interface AadharMasterService {

	public AadharMaster checkAadhar(String aadhar_number);
	
}
