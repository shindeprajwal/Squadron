package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gov.model.StudentApplication;

@Repository 
public class StudentApplicationDaoImpl implements StudentApplicationDao{

	@PersistenceContext 
	EntityManager entitymanager;

	@Transactional 
	public int createApplication(StudentApplication studentApplication) 
	{ 
		entitymanager.clear();
		entitymanager.merge(studentApplication);
		return 1; 
	}

	public List<StudentApplication> readApplicationByAadhar(String aadhar_number) {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where s.aadhar_number='"+aadhar_number+"'",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}

	@Transactional
	public List<StudentApplication> readApplicationByInstCode(int institute_code) {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where s.institute_code="+institute_code+" AND s.status='Ongoing'",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}
	
	@Transactional
	public int acceptStatus(int application_id) {
		Query query = entitymanager.createQuery("Update StudentApplication s set s.status='Nodal' where s.application_id="+application_id+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
	}

	@Transactional
	public int rejectStatus(int application_id) {
		Query query = entitymanager.createQuery("Update StudentApplication s set s.status='Rejected' where s.application_id="+application_id+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
		
	}

	@Transactional
	public List<StudentApplication> readApplicationByStatus() {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where s.status='Nodal'",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}

	@Transactional
	public int acceptStatusNodal(int application_id) {
		Query query = entitymanager.createQuery("Update StudentApplication s set s.status='Minister' where s.application_id="+application_id+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
	}

	@Transactional
	public int rejectStatusNodal(int application_id) {
		Query query = entitymanager.createQuery("Update StudentApplication s set s.status='Rejected' where s.application_id="+application_id+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
	}
	public List<StudentApplication> readApplicationByStatus1() {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where  s.status='Ongoing' ",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}


}