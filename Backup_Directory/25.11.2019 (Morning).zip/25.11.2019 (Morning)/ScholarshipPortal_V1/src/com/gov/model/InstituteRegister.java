package com.gov.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="INSTITUTE_REGISTER")
@SequenceGenerator(name="INST_SEQ", sequenceName="INST_SEQ" , initialValue=1, allocationSize=1)
public class InstituteRegister implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="INST_SEQ")
	@Column(name="INSTITUTE_ID")
	private int institute_id;
	@Column(name="INSTITUTE_CODE")
	private int institute_code;
	@Column(name="INSTITUTE_NAME")
	private String institute_name;
	@Column(name="DISE_CODE")
	private int dise_code;
	@Column(name="LOCATION")
	private String location;
	@Column(name="INSTITUTE_TYPE")
	private String institute_type;
	@Column(name="UNIVERSITY_NAME")
	private String university_name;
	@Column(name="ADMISSION_YEAR")
	private int admission_year;
	@Column(name="ADDRESS_LINE1")
	private String address_line1;
	@Column(name="ADDRESS_LINE2")
	private String address_line2;
	@Column(name="CITY")
	private String city;
	@Column(name="DISTRICT")
	private String district;
	@Column(name="STATE")
	private String state;
	@Column(name="PINCODE")
	private int pincode;
	@Column(name="PRINCIPAL_NAME ")
	private String principal_name;
	@Column(name="CONTACT_NUMBER ")
	private int contact_number;
	@Column(name="INST_CERTIFICATE")
	private String inst_certificate;
	@Column(name="AFF_UNIV_CERTIFICATE")
	private String aff_univ_certificate;
	@Column(name="USERNAME")
	private String user_name;
	
	public InstituteRegister() {
		super();
	}

	public InstituteRegister(int institute_id, int institute_code, String institute_name, int dise_code,
			String location, String institute_type, String university_name, int admission_year, String address_line1,
			String address_line2, String city, String district, String state, int pincode, String principal_name,
			int contact_number, String inst_certificate, String aff_univ_certificate, String user_name) {
		super();
		this.institute_id = institute_id;
		this.institute_code = institute_code;
		this.institute_name = institute_name;
		this.dise_code = dise_code;
		this.location = location;
		this.institute_type = institute_type;
		this.university_name = university_name;
		this.admission_year = admission_year;
		this.address_line1 = address_line1;
		this.address_line2 = address_line2;
		this.city = city;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
		this.principal_name = principal_name;
		this.contact_number = contact_number;
		this.inst_certificate = inst_certificate;
		this.aff_univ_certificate = aff_univ_certificate;
		this.user_name = user_name;
	}

	public int getInstitute_id() {
		return institute_id;
	}

	public void setInstitute_id(int institute_id) {
		this.institute_id = institute_id;
	}

	public int getInstitute_code() {
		return institute_code;
	}

	public void setInstitute_code(int institute_code) {
		this.institute_code = institute_code;
	}

	public String getInstitute_name() {
		return institute_name;
	}

	public void setInstitute_name(String institute_name) {
		this.institute_name = institute_name;
	}

	public int getDise_code() {
		return dise_code;
	}

	public void setDise_code(int dise_code) {
		this.dise_code = dise_code;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getInstitute_type() {
		return institute_type;
	}

	public void setInstitute_type(String institute_type) {
		this.institute_type = institute_type;
	}

	public String getUniversity_name() {
		return university_name;
	}

	public void setUniversity_name(String university_name) {
		this.university_name = university_name;
	}

	public int getAdmission_year() {
		return admission_year;
	}

	public void setAdmission_year(int admission_year) {
		this.admission_year = admission_year;
	}

	public String getAddress_line1() {
		return address_line1;
	}

	public void setAddress_line1(String address_line1) {
		this.address_line1 = address_line1;
	}

	public String getAddress_line2() {
		return address_line2;
	}

	public void setAddress_line2(String address_line2) {
		this.address_line2 = address_line2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getPrincipal_name() {
		return principal_name;
	}

	public void setPrincipal_name(String principal_name) {
		this.principal_name = principal_name;
	}

	public int getContact_number() {
		return contact_number;
	}

	public void setContact_number(int contact_number) {
		this.contact_number = contact_number;
	}

	public String getInst_certificate() {
		return inst_certificate;
	}

	public void setInst_certificate(String inst_certificate) {
		this.inst_certificate = inst_certificate;
	}

	public String getAff_univ_certificate() {
		return aff_univ_certificate;
	}

	public void setAff_univ_certificate(String aff_univ_certificate) {
		this.aff_univ_certificate = aff_univ_certificate;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String toString() {
		return "InstituteRegister [institute_id=" + institute_id + ", institute_code=" + institute_code
				+ ", institute_name=" + institute_name + ", dise_code=" + dise_code + ", location=" + location
				+ ", institute_type=" + institute_type + ", university_name=" + university_name + ", admission_year="
				+ admission_year + ", address_line1=" + address_line1 + ", address_line2=" + address_line2 + ", city="
				+ city + ", district=" + district + ", state=" + state + ", pincode=" + pincode + ", principal_name="
				+ principal_name + ", contact_number=" + contact_number + ", inst_certificate=" + inst_certificate
				+ ", aff_univ_certificate=" + aff_univ_certificate + ", user_name=" + user_name + "]";
	}
	
	
	
}
