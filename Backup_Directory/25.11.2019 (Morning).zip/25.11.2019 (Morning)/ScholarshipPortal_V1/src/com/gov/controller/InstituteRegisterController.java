package com.gov.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.gov.model.InstituteRegister;
import com.gov.model.LoginMaster;
import com.gov.service.InstituteRegisterService;
import com.gov.service.LoginService;
//Integrated institute reg. controller
@Controller
public class InstituteRegisterController {
	@Autowired
	private LoginService loginservice;
	@Autowired
	private InstituteRegisterService instituteRegisterService;
	@Autowired
	private InstituteRegister instituteRegister;
	@Autowired
	private LoginMaster login;
	@Autowired
	private LoginMaster login2;
	
	@RequestMapping(path="instituteRegister",method=RequestMethod.GET)
	public String instituteRegisterPage(){
		return "INSTITUTE_REGISTER";
	}
	
	@RequestMapping(path="instituteRegister.do",method=RequestMethod.POST)
	public String instituteRegister(@RequestParam("institute_code") int institute_code,
			@RequestParam("ilist") String institute_name,
			@RequestParam("user_name") String user_name,
			@RequestParam("password") String password,
			@RequestParam("email") String email,
			@RequestParam("dise_code") int dise_code,
			@RequestParam("location") String location,
			@RequestParam("institute_type") String institute_type,
			@RequestParam("university_name") String university_name,
			@RequestParam("institute_year") int admission_year,
			@RequestParam("address_line1")String address_line1,
			@RequestParam("address_line2") String address_line2,
			@RequestParam("city") String city,
			@RequestParam("institute_district") String district,
			@RequestParam("slist") String state,
			@RequestParam("pincode")int pincode,
			@RequestParam("institute_head_name")String principal_name,
			@RequestParam("contact_number") int contact_number,
			@RequestParam("institute_certificate") MultipartFile institute_certificate,
			@RequestParam("university_certificate") MultipartFile university_certificate) 
	{
		
		
		String rootPath = "D:/Institute";
		String institute_cert_path = rootPath+"/"+institute_certificate.getOriginalFilename();
		String university_cert_path = rootPath+"/"+university_certificate.getOriginalFilename();
		/*File dir1 = new File( rootPath + File.separator +  institute_code);*/
			try {
				
				institute_certificate.transferTo(new File(institute_cert_path));
				university_certificate.transferTo(new File(university_cert_path));
				
			} catch (IOException e) {
				System.out.println("Failed to upload file" +e);
			}
	
		login2.setRole("Institute");
		login2.setUser_name(user_name);
		login2.setPassword(password);
		login2.setEmail(email);
		instituteRegister.setInstitute_name(institute_name);
		instituteRegister.setDise_code(dise_code);
		instituteRegister.setInstitute_type(institute_type);
		instituteRegister.setUniversity_name(university_name);
		instituteRegister.setAdmission_year(admission_year);
		instituteRegister.setAddress_line2(address_line2);
		instituteRegister.setAddress_line1(address_line1);
		instituteRegister.setCity(city);
		instituteRegister.setDistrict(district);
		instituteRegister.setState(state);
		instituteRegister.setPincode(pincode);
		instituteRegister.setPrincipal_name(principal_name);
		instituteRegister.setContact_number(contact_number);
		instituteRegister.setLocation(location);
		instituteRegister.setInstitute_code(institute_code);
		instituteRegister.setInst_certificate(institute_cert_path);
		instituteRegister.setAff_univ_certificate(university_cert_path);
		instituteRegister.setUser_name(user_name);
		boolean result=instituteRegisterService.addInstitute(instituteRegister);
		boolean result1=loginservice.addUser(login2);
		if(result&result1)
		{
		return "HOME";
		}
		else
		{
		return "ERROR";	
		}
		
	}
		
		@RequestMapping(path="instuteRegisterSuccess",method=RequestMethod.GET)
		public String instituteRegistrationSuccessPage(){
			return "INSTITUTE__REGISTRATION_SUCCESS";
		}
	}
