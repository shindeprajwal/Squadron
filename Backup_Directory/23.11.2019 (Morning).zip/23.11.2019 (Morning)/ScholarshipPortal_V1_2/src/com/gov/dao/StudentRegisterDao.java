package com.gov.dao;

import com.gov.model.StudentRegister;

public interface StudentRegisterDao {
	
	public int createStudent(StudentRegister studentregister);

}
