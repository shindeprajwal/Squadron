package com.gov.dao;

import java.util.List;

import com.gov.model.StudentDocs;

public interface StudentDocsDao {

	public int createStudentDocs(StudentDocs docs);
	
	public List<StudentDocs> readDocumentByStudentId(int student_id);
	
	public int insertBonafideCertificate(int student_id,String bonafide_cert);
	
}
