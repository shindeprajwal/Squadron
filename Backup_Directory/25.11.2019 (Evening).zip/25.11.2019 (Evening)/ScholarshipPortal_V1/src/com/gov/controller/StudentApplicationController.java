package com.gov.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.gov.model.StudentApplication;
import com.gov.service.StudentApplicationService;

@Controller
public class StudentApplicationController {

	@Autowired
	StudentApplicationService studentApplicationService;

	@Autowired
	StudentApplication studentApplication;
	
	private HttpSession session;

	@RequestMapping(path="addStudentApplication")
	public String addStudentApplicationPage() 
	{ 
		return "STUDENT_APPLICATION"; 
	}

	@RequestMapping(path="addStudentApplication.do",method=RequestMethod.POST)
	public String addStudentApplication(StudentApplication studentApplication,
			@RequestParam("student_photograph") MultipartFile student_photograph ,
			@RequestParam("domicile_certificate") MultipartFile domicile_certificate,
			@RequestParam("institute_id_card") MultipartFile institute_id_card,
			@RequestParam("caste_certificate") MultipartFile caste_certificate,
			@RequestParam("income_certificate") MultipartFile income_certificate,
			@RequestParam("previous_year_marksheet") MultipartFile previous_year_marksheet,
			@RequestParam("fee_receipt") MultipartFile fee_receipt,
			@RequestParam("bank_passbook") MultipartFile bank_passbook,
			@RequestParam("aadhar_card") MultipartFile aadhar_card,
			@RequestParam("marksheet") MultipartFile marksheet)
	{
		String rootPath = "D:/Student_Application"; //change path
		String student_photo  = rootPath+"/"+student_photograph.getOriginalFilename();
		String domicile_cert = rootPath+"/"+domicile_certificate.getOriginalFilename();
		String inst_id_card = rootPath+"/"+institute_id_card.getOriginalFilename();
		String caste_cert = rootPath+"/"+caste_certificate.getOriginalFilename();
		String income_cert = rootPath+"/"+income_certificate.getOriginalFilename();
		String previous_marksheet = rootPath+"/"+previous_year_marksheet.getOriginalFilename();
		String fee_rcpt = rootPath+"/"+fee_receipt.getOriginalFilename();
		String bank_pass = rootPath+"/"+bank_passbook.getOriginalFilename();
		String aadhar = rootPath+"/"+aadhar_card.getOriginalFilename();
		String  mark_sheet = rootPath+"/"+marksheet.getOriginalFilename();
		/*File dir1 = new File( rootPath + File.separator +  institute_code);*/
			try {
				
				student_photograph.transferTo(new File(student_photo));
				domicile_certificate.transferTo(new File(domicile_cert));
				institute_id_card.transferTo(new File(inst_id_card));
				caste_certificate.transferTo(new File(caste_cert));
				income_certificate.transferTo(new File(income_cert));
				previous_year_marksheet.transferTo(new File(previous_marksheet));
				fee_receipt.transferTo(new File(fee_rcpt));
				bank_passbook.transferTo(new File(bank_pass));
				aadhar_card.transferTo(new File(aadhar));
				marksheet.transferTo(new File(mark_sheet));
				
			} catch (IOException e) {
				System.out.println("Failed to upload file" +e);
			}
			
		studentApplication.setStatus("Ongoing"); //New Git creds
		boolean result= studentApplicationService.addApplication(studentApplication);
		if(result) 
		{ 
			return "STUDENT_HOME"; 
		} else
		{ 
			return "ERROR"; 
		} 
	}
	
	@RequestMapping(path="studentApplicationRedirect",method=RequestMethod.GET)
	public String studentApplicationView()
	{
		return "STUDENT_APPLICATION_VIEW";
	}
	

}
