package com.gov.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.gov.model.AadharMaster;

@Repository
public class AadharMasterDaoImpl implements AadharMasterDao{
	
	@PersistenceContext
	private EntityManager entitymanager;

	public AadharMaster readAadhar(String aadhar_number) {
		AadharMaster aadhar = entitymanager.find(AadharMaster.class, aadhar_number);
		return aadhar;
	}

}
