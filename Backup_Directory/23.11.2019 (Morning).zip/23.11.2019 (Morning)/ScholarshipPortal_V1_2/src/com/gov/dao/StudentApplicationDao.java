
  package com.gov.dao;
  
  import com.gov.model.StudentApplication;
  
  public interface StudentApplicationDao {
  
  public int createApplication(StudentApplication studentApplication);
  
  }
 