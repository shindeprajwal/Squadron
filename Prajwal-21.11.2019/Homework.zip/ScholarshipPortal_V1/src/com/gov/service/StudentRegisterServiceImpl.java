package com.gov.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.StudentRegisterDao;
import com.gov.model.StudentRegister;

@Service
public class StudentRegisterServiceImpl implements StudentRegisterService{
	
	@Autowired
	StudentRegisterDao dao;
	
	@Transactional
	public boolean addStudent(StudentRegister studentregister){
		int result= dao.createStudent(studentregister);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}
}
