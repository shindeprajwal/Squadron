package com.gov.service;

import com.gov.model.LoginMaster;

public interface LoginService {
	
	public boolean checkLogin(String username,String password);
	
	public LoginMaster checkRole(String username);
	
	public boolean addUser(LoginMaster loginmaster);
	
}
