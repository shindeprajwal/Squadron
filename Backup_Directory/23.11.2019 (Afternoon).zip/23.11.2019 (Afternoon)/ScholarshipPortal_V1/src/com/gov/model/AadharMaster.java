package com.gov.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="AADHAR_MASTER")
public class AadharMaster implements Serializable{
	@Id
	@Column(name="AADHAR_NUMBER")
	private String aadhar_number;
	@Column(name="NAME")
	private String name;
	@Column(name="MOBILE_NUMBER")
	private String mobile_number;
	
	public AadharMaster() {
		super();
	}

	public AadharMaster(String aadhar_number, String name, String mobile_number) {
		super();
		this.aadhar_number = aadhar_number;
		this.name = name;
		this.mobile_number = mobile_number;
	}

	public String getAadhar_number() {
		return aadhar_number;
	}

	public void setAadhar_number(String aadhar_number) {
		this.aadhar_number = aadhar_number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String toString() {
		return "AadharMaster [aadhar_number=" + aadhar_number + ", name=" + name + ", mobile_number=" + mobile_number
				+ "]";
	}
	
	

}
