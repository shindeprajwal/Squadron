package com.gov.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="STUDENT_DOCUMENTS")
@SequenceGenerator(name="DOCS_SEQ", sequenceName="DOCS_SEQ" , initialValue=1, allocationSize=1)
public class StudentDocs implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DOCS_SEQ")
	@Column (name="DOCS_ID")
	private int docs_id;
	@Column (name="STUDENT_ID")
	private int student_id;
	@Column (name="STUDENT_PHOTO")
	private String student_photo;
	@Column (name="DOMICILE_CERT")
	private String domicile_cert;
	@Column (name="INST_ID_CARD")
	private String inst_id_card;
	@Column (name="CASTE_CERT")
	private String caste_cert;
	@Column (name="INCOME_CERT")
	private String income_cert;
	@Column (name="PREVIOUS_MARKSHEET")
	private String previous_marksheet;
	@Column (name="FEE_RCPT")
	private String fee_rcpt;
	@Column (name="BANK_PASS")
	private String bank_pass;
	@Column (name="AADHAR")
	private String aadhar;
	@Column (name="MARK_SHEET")
	private String mark_sheet;
	@Column (name="BONAFIDE_CERT")
	private String bonafide_cert;
	
	public StudentDocs() {
		super();
	}

	public StudentDocs(int student_id, String student_photo, String domicile_cert, String inst_id_card,
			String caste_cert, String income_cert, String previous_marksheet, String fee_rcpt, String bank_pass,
			String aadhar, String mark_sheet, String bonafide_cert) {
		super();
		this.student_id = student_id;
		this.student_photo = student_photo;
		this.domicile_cert = domicile_cert;
		this.inst_id_card = inst_id_card;
		this.caste_cert = caste_cert;
		this.income_cert = income_cert;
		this.previous_marksheet = previous_marksheet;
		this.fee_rcpt = fee_rcpt;
		this.bank_pass = bank_pass;
		this.aadhar = aadhar;
		this.mark_sheet = mark_sheet;
		this.bonafide_cert = bonafide_cert;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_photo() {
		return student_photo;
	}

	public void setStudent_photo(String student_photo) {
		this.student_photo = student_photo;
	}

	public String getDomicile_cert() {
		return domicile_cert;
	}

	public void setDomicile_cert(String domicile_cert) {
		this.domicile_cert = domicile_cert;
	}

	public String getInst_id_card() {
		return inst_id_card;
	}

	public void setInst_id_card(String inst_id_card) {
		this.inst_id_card = inst_id_card;
	}

	public String getCaste_cert() {
		return caste_cert;
	}

	public void setCaste_cert(String caste_cert) {
		this.caste_cert = caste_cert;
	}

	public String getIncome_cert() {
		return income_cert;
	}

	public void setIncome_cert(String income_cert) {
		this.income_cert = income_cert;
	}

	public String getPrevious_marksheet() {
		return previous_marksheet;
	}

	public void setPrevious_marksheet(String previous_marksheet) {
		this.previous_marksheet = previous_marksheet;
	}

	public String getFee_rcpt() {
		return fee_rcpt;
	}

	public void setFee_rcpt(String fee_rcpt) {
		this.fee_rcpt = fee_rcpt;
	}

	public String getBank_pass() {
		return bank_pass;
	}

	public void setBank_pass(String bank_pass) {
		this.bank_pass = bank_pass;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getMark_sheet() {
		return mark_sheet;
	}

	public void setMark_sheet(String mark_sheet) {
		this.mark_sheet = mark_sheet;
	}

	public String getBonafide_cert() {
		return bonafide_cert;
	}

	public void setBonafide_cert(String bonafide_cert) {
		this.bonafide_cert = bonafide_cert;
	}

	public String toString() {
		return "StudentDocs [docs_id=" + docs_id + ", student_id=" + student_id + ", student_photo=" + student_photo
				+ ", domicile_cert=" + domicile_cert + ", inst_id_card=" + inst_id_card + ", caste_cert=" + caste_cert
				+ ", income_cert=" + income_cert + ", previous_marksheet=" + previous_marksheet + ", fee_rcpt="
				+ fee_rcpt + ", bank_pass=" + bank_pass + ", aadhar=" + aadhar + ", mark_sheet=" + mark_sheet
				+ ", bonafide_cert=" + bonafide_cert + "]";
	}

	
	
}