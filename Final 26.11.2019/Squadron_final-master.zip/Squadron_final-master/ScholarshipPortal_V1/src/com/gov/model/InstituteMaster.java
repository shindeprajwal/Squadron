package com.gov.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
@Entity
@Table(name="INSTITUTE_MASTER")
public class InstituteMaster implements Serializable{
	@Id
	@Column(name="INSTITUTE_CODE")
	private int institute_code;
	@Column(name="INSTITUTE_NAME")
	private String institute_name;
	@Column(name="EMAIL")
	private String email;
	@Column(name="STATE")
	private String state;
	@Column(name="INSTITUTE_TYPE")
	private String institute_type;
	
	public InstituteMaster() {
		super();
	}

	public InstituteMaster(int institute_code, String institute_name, String email, String state,
			String institute_type) {
		super();
		this.institute_code = institute_code;
		this.institute_name = institute_name;
		this.email = email;
		this.state = state;
		this.institute_type = institute_type;
	}

	public int getInstitute_code() {
		return institute_code;
	}

	public void setInstitute_code(int institute_code) {
		this.institute_code = institute_code;
	}

	public String getInstitute_name() {
		return institute_name;
	}

	public void setInstitute_name(String institute_name) {
		this.institute_name = institute_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getInstitute_type() {
		return institute_type;
	}

	public void setInstitute_type(String institute_type) {
		this.institute_type = institute_type;
	}

	@Override
	public String toString() {
		return "InstituteMaster [institute_code=" + institute_code + ", institute_name=" + institute_name + ", email="
				+ email + ", state=" + state + ", institute_type=" + institute_type + "]";
	}

	
	
	
}
