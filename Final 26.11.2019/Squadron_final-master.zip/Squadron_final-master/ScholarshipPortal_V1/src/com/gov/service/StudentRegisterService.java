package com.gov.service;

import java.util.List;

import com.gov.model.StudentRegister;

public interface StudentRegisterService {
	
	public boolean addStudent(StudentRegister studentregister);
	
	public List<StudentRegister> readStudentByAadharId(String aadhar_number);
	


}
