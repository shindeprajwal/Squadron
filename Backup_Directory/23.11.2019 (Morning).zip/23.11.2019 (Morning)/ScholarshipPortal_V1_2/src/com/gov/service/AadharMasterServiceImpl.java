package com.gov.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gov.dao.AadharMasterDao;
import com.gov.model.AadharMaster;

@Service
public class AadharMasterServiceImpl implements AadharMasterService{
	
	@Autowired
	AadharMasterDao dao;
	
	public AadharMaster checkAadhar(String aadhar_number) {
		AadharMaster aadharmaster = dao.readAadhar(aadhar_number);
		if(aadharmaster!=null)
		{
			return aadharmaster;
		}else
		{
			return null;
		}
	}

}
