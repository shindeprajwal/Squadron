package com.gov.dao;

import java.util.List;

import com.gov.model.StudentRegister;

public interface StudentRegisterDao {
	
	public int createStudent(StudentRegister studentregister);
	
	public List<StudentRegister> findStudentByAadharId(String aadhar_number);
	


}
