package com.gov.controller;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gov.model.LoginMaster;
import com.gov.model.StudentRegister;
import com.gov.service.LoginService;
import com.gov.service.StudentRegisterService;

@Controller
public class ScholarshipController {
	@Autowired
	private LoginService loginservice;
	@Autowired
	private LoginMaster login;
	@Autowired
	private MailSender mailSender;
	@Autowired
	private SimpleMailMessage message;
	@Autowired
	private StudentRegisterService studentRegisterService;
	@Autowired
	private StudentRegister studentregister;
	
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String homePage(){
		return "HOME";
	}
	
	@RequestMapping(path="studentHome", method=RequestMethod.GET)
	public String loginPage()
	{
		return "STUDENT_HOME";
	}
	
	@RequestMapping(path="login.do", method=RequestMethod.POST)
	public String loginUsers(@RequestParam("username") String username,@RequestParam("password") String password){
		boolean result = loginservice.checkLogin(username, password);
		login = loginservice.checkRole(username);
		if(result)
		{
			String role=login.getRole();
			if(role.equals("Student"))
			{
				return "STUDENT_HOME";
			}
			else if(role.equals("Institute"))
			{
				return "INSTITUTE_HOME";
			}else if(role.equals("Nodal"))
			{
				return "NODAL_HOME";
			}else
			{
				return "MINISTRY_HOME";
			}
		}else 
		{
			return "ERROR";
		}
		
		
		}
	
	@RequestMapping(path="error", method=RequestMethod.GET)
	public String ErrorPage(){
		return "ERROR";
	}
	
	@RequestMapping(path="instituteHome", method=RequestMethod.GET)
	public String instituteHomePage()
	{
		return "INSTITUTE_HOME";
	}
	
	@RequestMapping(path="forgotPassword", method=RequestMethod.GET)
	public String forgotPasswordPage()
	{
		return "FORGOT_PASSWORD";
	}
	
	@RequestMapping(path="forgotPassword.do", method=RequestMethod.POST)
	public String forgotPassword(@RequestParam("user_name") String username){
		LoginMaster login = loginservice.checkRole(username);
		String email = login.getEmail();
		String uname = login.getUser_name();
		String pass = login.getPassword();
		message.setTo(email); //set a proper recipient of the mail
		message.setSubject("Scholarship Portal : Forgot Password Request");
		message.setText("Hello! "+uname+" \nYour Password is "+pass+".");
		mailSender.send(message);
		return "FORGOT_PASSWORD_SUCCESS";
	}
	
	@RequestMapping(path="forgotPasswordSuccess", method=RequestMethod.GET)
	public String forgotPasswordSuccessPage()
	{
		return "FORGOT_PASSWORD_SUCCESS";
	}
	
	@RequestMapping(path="nodalHome", method=RequestMethod.GET)
	public String nodalHomePage()
	{
		return "NODAL_HOME";
	}
	
	@RequestMapping(path="ministryHome", method=RequestMethod.GET)
	public String ministryHomePage(){
		return "MINISTRY_HOME";
	}
	
	@RequestMapping(path="studentRegister",method=RequestMethod.GET)
	public String studentRegisterPage(){
		return "STUDENT_REGISTRATION";																
	}
	
	@RequestMapping(path="studentRegister.do",method=RequestMethod.POST)
	public String studentRegister(@RequestParam("aadhar_no") String aadhar_no,@RequestParam("student_name") String student_name,
								  @RequestParam("date_of_birth") Date date_of_birth, @RequestParam("gender") String gender,
								  @RequestParam("mobile_no") String mobile_no, @RequestParam("email") String email,
								  @RequestParam("slist") String slist, @RequestParam("district") String district,
								  @RequestParam("bank_account_no") String bank_account_no, @RequestParam("bank_ifsc") String bank_ifsc,
								  @RequestParam("bank_account_name") String bank_account_name,@RequestParam("password")String password){
		
		studentregister.setAadhar_number(aadhar_no);
		studentregister.setBank_account_number(bank_account_no);
		studentregister.setDate_of_birth(date_of_birth);
		studentregister.setDistrict(district);
		studentregister.setDomicile_state(slist);
		studentregister.setEmail(email);
		studentregister.setGender(gender);
		studentregister.setIfsc_code(bank_ifsc);
		studentregister.setBank_name(bank_account_name);
		studentregister.setMobile_number(mobile_no);
		studentregister.setStudent_name(student_name);
		login.setUser_name(aadhar_no);
		login.setRole("Student");
		login.setPassword(password);
		login.setEmail(email);
		boolean result = studentRegisterService.addStudent(studentregister);
		boolean result1 = loginservice.addUser(login);
		if(result&result1)
		{
			return "HOME";
		}else
		{
			return "ERROR";
		}
		
	}
}









