package com.gov.service;

import java.util.List;

import com.gov.model.StudentApplication;

public interface StudentApplicationService {

	public boolean addApplication(StudentApplication studentApplication);
	
	public List<StudentApplication> findApplicationByAadhar(String aadhar_number);
	
	public List<StudentApplication> findApplicationByInstCode(int institute_code);
}
