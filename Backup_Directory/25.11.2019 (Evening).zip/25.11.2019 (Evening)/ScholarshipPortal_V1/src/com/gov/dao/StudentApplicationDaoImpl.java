package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gov.model.StudentApplication;

@Repository public class StudentApplicationDaoImpl implements StudentApplicationDao{

	@PersistenceContext 
	EntityManager entitymanager;

	@Transactional 
	public int createApplication(StudentApplication studentApplication) 
	{ 
		entitymanager.clear();
		entitymanager.merge(studentApplication);
		return 1; 
	}

	public List<StudentApplication> readApplicationByAadhar(String aadhar_number) {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where s.aadhar_number='"+aadhar_number+"'",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}

	public List<StudentApplication> readApplicationByInstCode(int institute_code) {
		TypedQuery<StudentApplication> query = entitymanager.createQuery("Select s from StudentApplication s where s.institute_code="+institute_code+"",StudentApplication.class);
		List<StudentApplication> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}

}