
  package com.gov.service;
  
  import com.gov.model.StudentApplication;
  
  public interface StudentApplicationService {
  
  public boolean addApplication(StudentApplication studentApplication);
  
  }
 