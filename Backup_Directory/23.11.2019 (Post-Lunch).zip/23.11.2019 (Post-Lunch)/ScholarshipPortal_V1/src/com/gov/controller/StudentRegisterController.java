/*package com.gov.controller;

import java.sql.Date;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gov.model.AadharMaster;
import com.gov.model.LoginMaster;
import com.gov.model.StudentRegister;
import com.gov.service.AadharMasterService;
import com.gov.service.LoginService;
import com.gov.service.StudentRegisterService;

@Controller
public class StudentRegisterController {
	@Autowired
	private LoginService loginservice; // Student Register
	@Autowired
	private LoginMaster login; // Student Register
	@Autowired
	private StudentRegisterService studentRegisterService; // Student Register
	@Autowired
	private StudentRegister studentregister; // Student Register
	@Autowired
	private AadharMaster aadharmaster; // Student Register
	@Autowired
	private AadharMasterService aadharMasterService; // Student Register
	
	
}
*/