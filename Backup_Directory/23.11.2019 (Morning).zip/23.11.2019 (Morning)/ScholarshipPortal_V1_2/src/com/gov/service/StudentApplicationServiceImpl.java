package com.gov.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.StudentApplicationDao;
import com.gov.model.StudentApplication;

@Service
public class StudentApplicationServiceImpl implements StudentApplicationService{
	
	@Autowired
	StudentApplicationDao dao;
	
	@Transactional
	public boolean addApplication(StudentApplication studentApplication) {
		int result	= dao.createApplication(studentApplication);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}

}
