
  package com.gov.model;
  
  import java.sql.Date;
  
  import javax.persistence.Column; import javax.persistence.Entity; import
  javax.persistence.GeneratedValue; import javax.persistence.GenerationType;
  import javax.persistence.Id; import javax.persistence.SequenceGenerator;
  import javax.persistence.Table;
  
  import org.springframework.context.annotation.Scope; import
  org.springframework.stereotype.Component;
  
  @Component
  
  @Scope(scopeName="prototype")
  
  @Entity
  
  @Table(name="STUDENT_APPLICATION")
  
  @SequenceGenerator(name="appl_seq", sequenceName="appl_seq" , initialValue=1,
  allocationSize=1) public class StudentApplication {
  
  @Id
  
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="appl_seq")
  
  @Column(name="APPLICATION_ID") private int application_id;
  
  @Column(name="AADHAR_NUMBER") private String aadhar_number;
  
  @Column(name="STUDENT_ID") private int student_id;
  
  @Column(name="STUDENT_NAME") private String student_name;
  
  @Column(name="FATHER_NAME") private String father_name;
  
  @Column(name="MOTHER_NAME") private String mother_name;
  
  @Column(name="PARENTS_OCCUPUTION") private String parents_occupation;
  
  @Column(name="ANNUAL_INCOME") private int annual_income;
  
  @Column(name="RELIGION") private String religion;
  
  @Column(name="INSTITUTE_NAME") private String institute_name;
  
  @Column(name="PRESENT_COURSE") private String present_course;
  
  @Column(name="PRESENT_YEAR") private String present_year;
  
  @Column(name="MODE_OF_STUDY") private String mode_of_study;
  
  @Column(name="CLASS_START_DATE") private Date class_start_date;
  
  @Column(name="UNIVERSITY_NAME") private String university_name;
  
  @Column(name="PREVIOUS_COURSE") private String previous_course;
  
  @Column(name="PREVIOUS_PASSING_YEAR") private String previous_passing_year;
  
  @Column(name="PREVIOUS_CLASS_PERCENT") private int previous_class_percent;
  
  @Column(name="SEAT_NUMBER") private int seat_number;
  
  @Column(name="BOARD_NAME") private String board_name;
  
  @Column(name="PASSING_YEAR") private String passing_year;
  
  @Column(name="PERCENT_OBTAINED") private int percent_obtained;
  
  @Column(name="TOTAL_FEES") private int total_fees;
  
  @Column(name="DISABILITY_TYPE") private String disability_type;
  
  @Column(name="MARITAL_STATUS") private String marital_status;
  
  @Column(name="ADDRESS_LINE1") private String address_line1;
  
  @Column(name="ADDRESS_LINE2") private String address_line2;
  
  @Column(name="CITY") private String city;
  
  @Column(name="DISTRICT") private String district;
  
  @Column(name="STATE") private String state;
  
  @Column(name="PINCODE") private String pincode;
  
  @Column(name="CONTACT_NUMBER") private String contact_number;
  
  @Column(name="SCHOLARSHIP_SCHEME") private String scholarship_scheme;
  
  @Column(name="INSTITUTE_CODE") private int institute_code;
  
  @Column(name="STATUS") private String status;
  
  public StudentApplication() { super(); }
  
  public StudentApplication( String aadhar_number, int student_id, String
  student_name, String father_name, String mother_name, String
  parents_occupation, int annual_income, String religion, String
  institute_name, String present_course, String present_year, String
  mode_of_study, Date class_start_date, String university_name, String
  previous_course, String previous_passing_year, int previous_class_percent,
  int seat_number, String board_name, String passing_year, int
  percent_obtained, int total_fees, String disability_type, String
  marital_status, String address_line1, String address_line2, String city,
  String district, String state, String pincode, String contact_number, String
  scholarship_scheme,int institute_code ,String status) { super();
  this.aadhar_number = aadhar_number; this.student_id = student_id;
  this.student_name = student_name; this.father_name = father_name;
  this.mother_name = mother_name; this.parents_occupation = parents_occupation;
  this.annual_income = annual_income; this.religion = religion;
  this.institute_name = institute_name; this.present_course = present_course;
  this.present_year = present_year; this.mode_of_study = mode_of_study;
  this.class_start_date = class_start_date; this.university_name =
  university_name; this.previous_course = previous_course;
  this.previous_passing_year = previous_passing_year;
  this.previous_class_percent = previous_class_percent; this.seat_number =
  seat_number; this.board_name = board_name; this.passing_year = passing_year;
  this.percent_obtained = percent_obtained; this.total_fees = total_fees;
  this.disability_type = disability_type; this.marital_status = marital_status;
  this.address_line1 = address_line1; this.address_line2 = address_line2;
  this.city = city; this.district = district; this.state = state; this.pincode
  = pincode; this.contact_number = contact_number; this.scholarship_scheme =
  scholarship_scheme; this.institute_code=institute_code; this.status=status; }
  
  public String getAadhar_number() { return aadhar_number; }
  
  public void setAadhar_number(String aadhar_number) { this.aadhar_number =
  aadhar_number; }
  
  public int getStudent_id() { return student_id; }
  
  public void setStudent_id(int student_id) { this.student_id = student_id; }
  
  public String getStudent_name() { return student_name; }
  
  public void setStudent_name(String student_name) { this.student_name =
  student_name; }
  
  public String getFather_name() { return father_name; }
  
  public void setFather_name(String father_name) { this.father_name =
  father_name; }
  
  public String getMother_name() { return mother_name; }
  
  public void setMother_name(String mother_name) { this.mother_name =
  mother_name; }
  
  public String getParents_occupation() { return parents_occupation; }
  
  public void setParents_occupation(String parents_occupation) {
  this.parents_occupation = parents_occupation; }
  
  public int getAnnual_income() { return annual_income; }
  
  public void setAnnual_income(int annual_income) { this.annual_income =
  annual_income; }
  
  public String getReligion() { return religion; }
  
  public void setReligion(String religion) { this.religion = religion; }
  
  public String getInstitute_name() { return institute_name; }
  
  public void setInstitute_name(String institute_name) { this.institute_name =
  institute_name; }
  
  public String getPresent_course() { return present_course; }
  
  public void setPresent_course(String present_course) { this.present_course =
  present_course; }
  
  public String getPresent_year() { return present_year; }
  
  public void setPresent_year(String present_year) { this.present_year =
  present_year; }
  
  public String getMode_of_study() { return mode_of_study; }
  
  public void setMode_of_study(String mode_of_study) { this.mode_of_study =
  mode_of_study; }
  
  public Date getClass_start_date() { return class_start_date; }
  
  public void setClass_start_date(Date class_start_date) {
  this.class_start_date = class_start_date; }
  
  public String getUniversity_name() { return university_name; }
  
  public void setUniversity_name(String university_name) { this.university_name
  = university_name; }
  
  public String getPrevious_course() { return previous_course; }
  
  public void setPrevious_course(String previous_course) { this.previous_course
  = previous_course; }
  
  public String getPrevious_passing_year() { return previous_passing_year; }
  
  public void setPrevious_passing_year(String previous_passing_year) {
  this.previous_passing_year = previous_passing_year; }
  
  public int getPrevious_class_percent() { return previous_class_percent; }
  
  public void setPrevious_class_percent(int previous_class_percent) {
  this.previous_class_percent = previous_class_percent; }
  
  public int getSeat_number() { return seat_number; }
  
  public void setSeat_number(int seat_number) { this.seat_number = seat_number;
  }
  
  public String getBoard_name() { return board_name; }
  
  public void setBoard_name(String board_name) { this.board_name = board_name;
  }
  
  public String getPassing_year() { return passing_year; }
  
  public void setPassing_year(String passing_year) { this.passing_year =
  passing_year; }
  
  public int getPercent_obtained() { return percent_obtained; }
  
  public void setPercent_obtained(int percent_obtained) { this.percent_obtained
  = percent_obtained; }
  
  public int getTotal_fees() { return total_fees; }
  
  public void setTotal_fees(int total_fees) { this.total_fees = total_fees; }
  
  public String getDisability_type() { return disability_type; }
  
  public void setDisability_type(String disability_type) { this.disability_type
  = disability_type; }
  
  public String getMarital_status() { return marital_status; }
  
  public void setMarital_status(String marital_status) { this.marital_status =
  marital_status; }
  
  public String getAddress_line1() { return address_line1; }
  
  public void setAddress_line1(String address_line1) { this.address_line1 =
  address_line1; }
  
  public String getAddress_line2() { return address_line2; }
  
  public void setAddress_line2(String address_line2) { this.address_line2 =
  address_line2; }
  
  public String getCity() { return city; }
  
  public void setCity(String city) { this.city = city; }
  
  public String getDistrict() { return district; }
  
  public void setDistrict(String district) { this.district = district; }
  
  public String getState() { return state; }
  
  public void setState(String state) { this.state = state; }
  
  public String getPincode() { return pincode; }
  
  public void setPincode(String pincode) { this.pincode = pincode; }
  
  public String getContact_number() { return contact_number; }
  
  public void setContact_number(String contact_number) { this.contact_number =
  contact_number; }
  
  public String getScholarship_scheme() { return scholarship_scheme; }
  
  public void setScholarship_scheme(String scholarship_scheme) {
  this.scholarship_scheme = scholarship_scheme; }
  
  public int getInstitute_code() { return institute_code; }
  
  public void setInstitute_code(int institute_code) { this.institute_code =
  institute_code; }
  
  public String getStatus() { return status; }
  
  public void setStatus(String status) { this.status = status; }
  
  
  public String toString() { return "StudentApplication [application_id=" +
  application_id + ", aadhar_number=" + aadhar_number + ", student_id=" +
  student_id + ", student_name=" + student_name + ", father_name=" +
  father_name + ", mother_name=" + mother_name + ", parents_occupation=" +
  parents_occupation + ", annual_income=" + annual_income + ", religion=" +
  religion + ", institute_name=" + institute_name + ", present_course=" +
  present_course + ", present_year=" + present_year + ", mode_of_study=" +
  mode_of_study + ", class_start_date=" + class_start_date +
  ", university_name=" + university_name + ", previous_course=" +
  previous_course + ", previous_passing_year=" + previous_passing_year +
  ", previous_class_percent=" + previous_class_percent + ", seat_number=" +
  seat_number + ", board_name=" + board_name + ", passing_year=" + passing_year
  + ", percent_obtained=" + percent_obtained + ", total_fees=" + total_fees +
  ", disability_type=" + disability_type + ", marital_status=" + marital_status
  + ", address_line1=" + address_line1 + ", address_line2=" + address_line2 +
  ", city=" + city + ", district=" + district + ", state=" + state +
  ", pincode=" + pincode + ", contact_number=" + contact_number +
  ", scholarship_scheme=" + scholarship_scheme + ", institute_code=" +
  institute_code + ", status=" + status + "]"; }
  
  }
 