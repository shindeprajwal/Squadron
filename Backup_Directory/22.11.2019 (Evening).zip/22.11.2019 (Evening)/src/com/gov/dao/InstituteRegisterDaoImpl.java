package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;
import com.gov.model.LoginMaster;
@Repository
public class InstituteRegisterDaoImpl implements InstituteRegisterDao{

	@PersistenceContext
	private EntityManager entitymanager;
	
	
	public int createInstitute(InstituteRegister instituteregister) {
		entitymanager.clear();
		entitymanager.merge(instituteregister);
		return 1;
	}


	public List<InstituteMaster> readAllInstituteDetails() {
		TypedQuery<InstituteMaster> query = entitymanager.createQuery("Select i from InstituteMaster i ",InstituteMaster.class);
		List<InstituteMaster> list= query.getResultList();
		return list;
	}


		
	}

