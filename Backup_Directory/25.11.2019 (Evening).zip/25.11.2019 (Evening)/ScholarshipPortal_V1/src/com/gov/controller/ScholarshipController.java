package com.gov.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gov.model.AadharMaster;
import com.gov.model.InstituteRegister;
import com.gov.model.LoginMaster;
import com.gov.model.StudentApplication;
import com.gov.model.StudentRegister;
import com.gov.service.AadharMasterService;
import com.gov.service.InstituteRegisterService;
import com.gov.service.LoginService;
import com.gov.service.StudentApplicationService;
import com.gov.service.StudentRegisterService;

@Controller
public class ScholarshipController {
	@Autowired
	private LoginService loginservice; // Student Register
	@Autowired
	private LoginMaster login; // Student Register
	@Autowired
	private LoginMaster login1;
	@Autowired
	private MailSender mailSender;
	@Autowired
	private SimpleMailMessage message;
	@Autowired
	private StudentRegisterService studentRegisterService; // Student Register
	@Autowired
	private StudentRegister studentregister; // Student Register
	@Autowired
	private AadharMaster aadharmaster; // Student Register
	@Autowired
	private AadharMasterService aadharMasterService; // Student Register
	@Autowired
	StudentApplicationService studentApplicationService;
	@Autowired
	StudentApplication studentApplication;
	@Autowired
	private InstituteRegisterService instituteRegisterService;
	
	private HttpSession session;
	
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String indexPage(){
		return "HOME";
	}
	
	@RequestMapping(path="home", method=RequestMethod.GET)
	public String homePage(){
		return "HOME";
	}
	
	@RequestMapping(path="aboutUs", method=RequestMethod.GET)
	public String aboutUsPage(){
		return "ABOUT_US";
	}
	
	@RequestMapping(path="contact", method=RequestMethod.GET)
	public String contactPage(){
		return "CONTACT";
	}
	
	@RequestMapping(path="studentHome", method=RequestMethod.GET)
	public String loginPage()
	{
		
		return "STUDENT_HOME";
	}
	//Committed
	@RequestMapping(path="login.do", method=RequestMethod.POST)
	public String loginUsers(@RequestParam("username") String username,@RequestParam("password") String password, 
							   HttpServletRequest request,Model model){
		
		List<StudentApplication> applList= studentApplicationService.findApplicationByAadhar(username);
		String result = loginservice.checkLogin(username, password);
		List<StudentRegister> list;
		if(result!=null){
			login = loginservice.checkRole(username);
			String role=login.getRole();
		switch(role)
		{
			case "Student":	session = request.getSession(true);
							list = studentRegisterService.readStudentByAadharId(username);
							session.setAttribute("studentName", list.get(0).getStudent_name());
							session.setAttribute("aadharNumber", list.get(0).getAadhar_number());
							session.setAttribute("email", list.get(0).getEmail());
							session.setAttribute("studentId", list.get(0).getStudent_id());
							session.setAttribute("role", role);
							if(applList!=null && applList.size()!=0)
							{	
								session.setAttribute("applId", applList.get(0).getApplication_id());
								session.setAttribute("applStatus", applList.get(0).getStatus());
							}
							return "redirect:studentHome";
		
			case "Institute":	session = request.getSession(true);
							 	session.setAttribute("userid", result);
							 	if(role!=null)
							 	{
							 	session.setAttribute("role1", role);
							 	}
							 	List<InstituteRegister> instList = instituteRegisterService.checkInstituteByUsername(username); 
							 	List<StudentApplication> applList1 = studentApplicationService.findApplicationByInstCode(instList.get(0).getInstitute_code());
							 	if(applList1!=null && applList1.size()!=0)
							 	{
							 		session.setAttribute("application_list", applList1);
							 	}
							 	return "redirect:instituteHome";	
		
			case "Nodal":	session = request.getSession(true);
							if(role!=null)
							{
							session.setAttribute("role2", role);
							}
							return "redirect:nodalHome";
							
			case "Ministry":	session = request.getSession(true);
								if(role!=null)
								{										
								session.setAttribute("role3", role);
								}
								return "redirect:ministryHome";
		
		default: return "ERROR";
		}
		}else
		{
			 return "ERROR" ;
		}
	}
	
	@RequestMapping(path="logout.do", method=RequestMethod.GET)
	public String logout(HttpServletRequest request){
		session = request.getSession(false);
		session.invalidate();
		return "LOGOUT";
	}
	
	
	@RequestMapping(path="homeAfterLogin", method=RequestMethod.GET)
	public String homeAfterLoginPage(){
		return "HOME_AFTER_LOGIN";
	}

	@RequestMapping(path="aboutUsAfterLogin", method=RequestMethod.GET)
	public String aboutUsAfterLoginPage(){
		return "ABOUT_US_AFTER_LOGIN";
	}
	
	@RequestMapping(path="contactAfterLogin", method=RequestMethod.GET)
	public String contactAfterLoginPage(){
		return "CONTACT_AFTER_LOGIN";
	}
	
		
	
	@RequestMapping(path="error", method=RequestMethod.GET)
	public String ErrorPage(){
		return "ERROR";
	}
	
	@RequestMapping(path="instituteHome", method=RequestMethod.GET)
	public String instituteHomePage()
	{
		return "INSTITUTE_HOME";
	}
	
	@RequestMapping(path="forgotPassword", method=RequestMethod.GET)
	public String forgotPasswordPage()
	{
		return "FORGOT_PASSWORD";
	}
	
	@RequestMapping(path="forgotPassword.do", method=RequestMethod.POST)
	public String forgotPassword(@RequestParam("user_name") String username)
	{
		LoginMaster login = loginservice.checkRole(username);
		String email = login.getEmail();
		String uname = login.getUser_name();
		String pass = login.getPassword();
		message.setTo(email); //set a proper recipient of the mail
		message.setSubject("Scholarship Portal : Forgot Password Request");
		message.setText("Hello! "+uname+" \nYour Password is "+pass+".");
		mailSender.send(message);
		return "FORGOT_PASSWORD_SUCCESS";
	}
	
	@RequestMapping(path="forgotPasswordSuccess", method=RequestMethod.GET)
	public String forgotPasswordSuccessPage()
	{
		return "FORGOT_PASSWORD_SUCCESS";
	}
	
	@RequestMapping(path="nodalHome", method=RequestMethod.GET)
	public String nodalHomePage()
	{
		return "NODAL_HOME";
	}
	
	@RequestMapping(path="ministryHome", method=RequestMethod.GET)
	public String ministryHomePage()
	{
		return "MINISTRY_HOME";
	}
	
	// Student Register
	@RequestMapping(path="checkUid.do")
	@ResponseBody
	public String checkLogin(@RequestParam("u_id") String username, HttpServletResponse response)
	{
		response.setContentType("text/html");
		login = loginservice.checkRole(username);
		if(login!=null)
		{
			return "";
		}else{
			return "false";
			}
	}
	
	// Student Register
	@RequestMapping(path="studentRegister",method=RequestMethod.GET)
	public String studentRegisterPage()
	{
		return "STUDENT_REGISTRATION";																
	}

	// Student Register
	@RequestMapping(path="studentRegister.do",method=RequestMethod.POST)
	public String studentRegister(@RequestParam("aadhar_no") String aadhar_no,@RequestParam("student_name") String student_name,
			@RequestParam("date_of_birth") Date date_of_birth, @RequestParam("gender") String gender,
			@RequestParam("mobile_no") String mobile_no, @RequestParam("email") String email,
			@RequestParam("slist") String slist, @RequestParam("city") String city,
			@RequestParam("bank_account_no") String bank_account_no, @RequestParam("bank_ifsc") String bank_ifsc,
			@RequestParam("bank_account_name") String bank_account_name,@RequestParam("password")String password)
	{
		login1.setRole("Student");
		login1.setUser_name(aadhar_no);
		login1.setPassword(password);
		login1.setEmail(email);
		studentregister.setAadhar_number(aadhar_no);
		studentregister.setBank_account_number(bank_account_no);
		studentregister.setDate_of_birth(date_of_birth);
		studentregister.setCity(city);
		studentregister.setDomicile_state(slist);
		studentregister.setEmail(email);
		studentregister.setGender(gender);
		studentregister.setIfsc_code(bank_ifsc);
		studentregister.setBank_name(bank_account_name);
		studentregister.setMobile_number(mobile_no);
		studentregister.setStudent_name(student_name);
		boolean result = studentRegisterService.addStudent(studentregister);
		boolean result1 = loginservice.addUser(login1);
		if(result&result1)
		{
			return "STUDENT_REGISTRATION_SUCCESS";
		}else
		{
			return "ERROR";
		}

	}

	// Student Register
	@RequestMapping(path="studentRegisterSuccess",method=RequestMethod.GET)
	public String studentRegistrationSuccessPage(){
		return "STUDENT_REGISTRATION_SUCCESS";
	}

	// Student Register
	@RequestMapping(path="checkAadhar.do")
	@ResponseBody
	public String checkAadharNo(@RequestParam("aadhar_no") String aadhar_no,HttpServletResponse response)
	{
		response.setContentType("text/html");
		aadharmaster = aadharMasterService.checkAadhar(aadhar_no);
		if(aadharmaster!=null)
		{
			return "";
		}else
		{
			return "false";
		}
	}
}









