package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;
import com.gov.model.LoginMaster;
@Repository
public class InstituteRegisterDaoImpl implements InstituteRegisterDao{

	@PersistenceContext
	private EntityManager entitymanager;
	
	
	public int createInstitute(InstituteRegister instituteregister) {
		entitymanager.clear();
		entitymanager.merge(instituteregister);
		return 1;
	}


	public List<InstituteMaster> readAllInstituteDetails() {
		TypedQuery<InstituteMaster> query = entitymanager.createQuery("Select i from InstituteMaster i ",InstituteMaster.class);
		List<InstituteMaster> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
		
	}
	public List<InstituteRegister> readAllInstitute() {
		TypedQuery<InstituteRegister> query = entitymanager.createQuery("Select i from InstituteRegister i where i.status='Unapproved' ",InstituteRegister.class);
		List<InstituteRegister> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
		
	}

	public List<InstituteRegister> readInstituteByUsername(String username) {
		TypedQuery<InstituteRegister> query = entitymanager.createQuery("Select i from InstituteRegister i where user_name='"+username+"'",InstituteRegister.class);
		List<InstituteRegister> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}

	@Transactional
	public int approveStatus(int institute_code) {
		Query query = entitymanager.createQuery("Update InstituteRegister i set i.status='Approved' where i.institute_code="+institute_code+"");
		int result = query.executeUpdate();
		if(result==1)
		{
			return 1;
		}else{
			return 0;
		}
	}

	@Transactional
	public int rejectStatus(int institute_code) {
			Query query = entitymanager.createQuery("Delete from InstituteRegister i where i.institute_code="+institute_code+"");
			int result = query.executeUpdate();
			if(result==1)
			{
				return 1;
			}else{
				return 0;
			}
	}
	public List<InstituteRegister> readInstituteByStatus1() {
		TypedQuery<InstituteRegister> query = entitymanager.createQuery("Select i from InstituteRegister i where status='Approved'",InstituteRegister.class);
		List<InstituteRegister> list= query.getResultList();
		if(list!=null)
		{
			return list;	
		}else{
			return null;
		}
	}


		
	}

