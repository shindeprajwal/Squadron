package com.gov.service;

import java.util.List;

import com.gov.model.StudentDocs;

public interface StudentDocsService {
	
	public boolean addStudentDocs(StudentDocs docs);
	
	public List<StudentDocs> findDocumentByStudentId(int student_id); 
	
	public boolean updateBonafideCert(int student_id,String bonafide_cert);
	


}
