package com.gov.dao;

import com.gov.model.LoginMaster;

public interface LoginDao {
	
	public int readLogin(String username,String password);
	
	public LoginMaster readRole(String username);
	
	public int createUser(LoginMaster loginmaster);
}
