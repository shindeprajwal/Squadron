package com.gov.dao;

import java.util.List;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;


public interface InstituteRegisterDao {

	public int createInstitute(InstituteRegister instituteregister);
	
	public List<InstituteMaster> readAllInstituteDetails(); 
	
	public List<InstituteRegister> readAllInstitute();
	
	public List<InstituteRegister> readInstituteByUsername(String username);
	
	public int approveStatus(int institute_code);
	
	public int rejectStatus(int institute_code);
	
	public List<InstituteRegister> readInstituteByStatus1();
}
