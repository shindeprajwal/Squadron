package com.gov.dao;
  
import java.util.List;

import com.gov.model.StudentApplication;
  
public interface StudentApplicationDao {
  
	public int createApplication(StudentApplication studentApplication);
	
	public List<StudentApplication> readApplicationByAadhar(String aadhar_number);
	
	public List<StudentApplication> readApplicationByInstCode(int institute_code);
}
 