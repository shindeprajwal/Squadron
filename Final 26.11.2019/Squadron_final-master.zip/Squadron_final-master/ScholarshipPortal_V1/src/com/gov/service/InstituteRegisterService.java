package com.gov.service;

import java.util.List;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;

public interface InstituteRegisterService {
	
	public boolean addInstitute(InstituteRegister instituteregister);
	
	public List<InstituteMaster> checkAllInstituteDetails();
	
	public List<InstituteRegister> checkAllInstitute();
	
	public List<InstituteRegister> checkInstituteByUsername(String username);
	
	public boolean acceptStatus(int institute_code);
	
	public boolean rejectStatus(int institute_code);

	public List<InstituteRegister> findInstituteByStatus1();
}
