package com.gov.dao;
  
import java.util.List;

import com.gov.model.StudentApplication;
  
public interface StudentApplicationDao {
  
	public int createApplication(StudentApplication studentApplication);
	
	public List<StudentApplication> readApplicationByAadhar(String aadhar_number);
	
	public List<StudentApplication> readApplicationByInstCode(int institute_code);
	
	public int acceptStatus(int application_id);
	
	public int rejectStatus(int application_id);
	
	public List<StudentApplication> readApplicationByStatus();
	
	public int acceptStatusNodal(int application_id);
	
	public int rejectStatusNodal(int application_id);
	
	public List<StudentApplication> readApplicationByStatus1();
}
 