
  package com.gov.dao;
  
  import javax.persistence.EntityManager; import
  javax.persistence.PersistenceContext;
  
  import org.springframework.stereotype.Repository; import
  org.springframework.transaction.annotation.Transactional;
  
  import com.gov.model.StudentApplication;
  
  @Repository public class StudentApplicationDaoImpl implements
  StudentApplicationDao{
  
  @PersistenceContext EntityManager entitymanager;
  
  @Transactional public int createApplication(StudentApplication
  studentApplication) { entitymanager.clear();
  entitymanager.merge(studentApplication); return 1; }
  
  }
 