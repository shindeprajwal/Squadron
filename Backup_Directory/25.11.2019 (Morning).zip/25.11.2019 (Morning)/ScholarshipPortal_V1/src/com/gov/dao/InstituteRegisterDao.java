package com.gov.dao;

import java.util.List;

import com.gov.model.InstituteMaster;
import com.gov.model.InstituteRegister;


public interface InstituteRegisterDao {

	public int createInstitute(InstituteRegister instituteregister);
	
	public List<InstituteMaster> readAllInstituteDetails(); 
	
	public List<InstituteRegister> readInstituteByUsername(String username);
}
