package com.gov.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.LoginDao;
import com.gov.model.LoginMaster;

@Service
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginDao dao;
	
	
	public boolean checkLogin(String username, String password) {
		int result = dao.readLogin(username, password);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
			
	}

	public LoginMaster checkRole(String username) {
		LoginMaster login = dao.readRole(username);
		if(login!=null){
			return login;	
		}else{
			return null;
		}
	}
	
	@Transactional
	public boolean addUser(LoginMaster loginmaster) {
		int result = dao.createUser(loginmaster);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}


}
