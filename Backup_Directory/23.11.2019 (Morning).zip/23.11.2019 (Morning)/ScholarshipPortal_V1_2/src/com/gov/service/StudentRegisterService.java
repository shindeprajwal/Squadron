package com.gov.service;

import com.gov.model.StudentRegister;

public interface StudentRegisterService {
	
	public boolean addStudent(StudentRegister studentregister);

}
