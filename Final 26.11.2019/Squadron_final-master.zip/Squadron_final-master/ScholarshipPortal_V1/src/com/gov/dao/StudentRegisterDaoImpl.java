package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gov.model.StudentRegister;

@Repository
public class StudentRegisterDaoImpl implements StudentRegisterDao {

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Transactional
	public int createStudent(StudentRegister studentregister) {
		entitymanager.clear();
		entitymanager.merge(studentregister);
		return 1;
	}

	public List<StudentRegister> findStudentByAadharId(String aadhar_number) {
		TypedQuery<StudentRegister> query = entitymanager.createQuery("Select s from StudentRegister s where s.aadhar_number='"+aadhar_number+"'",StudentRegister.class);
		List<StudentRegister> list= query.getResultList();
		return list;
	}



}
