package com.gov.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gov.dao.StudentRegisterDao;
import com.gov.model.StudentRegister;

@Service
public class StudentRegisterServiceImpl implements StudentRegisterService{
	
	@Autowired
	StudentRegisterDao dao;
	
	@Transactional
	public boolean addStudent(StudentRegister studentregister){
		int result= dao.createStudent(studentregister);
		if(result==1)
		{
			return true;
		}else{
			return false;
		}
	}

	public List<StudentRegister> readStudentByAadharId(String aadhar_number) {
		List<StudentRegister> list = dao.findStudentByAadharId(aadhar_number);
		if(list!=null)
		{
			return list;
		}else{
			return null;
		}
	}
	
	
}
