package com.gov.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.gov.model.LoginMaster;

@Repository
public class LoginDaoImpl implements LoginDao{
	
	@PersistenceContext
	private EntityManager entitymanager;
	
	public int readLogin(String username, String password){
		TypedQuery<LoginMaster> query = entitymanager.createQuery("Select l from LoginMaster l where l.user_name='"+username+"' and l.password='"+password+"'",LoginMaster.class);
		List<LoginMaster> list= query.getResultList();
		return list.size();
	}

	public LoginMaster readRole(String username) {
		LoginMaster login = entitymanager.find(LoginMaster.class,username);
		if(login!=null){
			return login;	
		}else{
			return null;
		}
		
	}

	public int createUser(LoginMaster loginmaster) {
		entitymanager.clear();
		entitymanager.merge(loginmaster);
		return 1;
	}

}
