
  package com.gov.controller;
  
  import org.springframework.beans.factory.annotation.Autowired; import
  org.springframework.stereotype.Controller; import
  org.springframework.web.bind.annotation.RequestMapping; import
  org.springframework.web.bind.annotation.RequestMethod;
  
  import com.gov.model.StudentApplication; import
  com.gov.service.StudentApplicationService;
  
  @Controller public class StudentApplicationController {
  
  @Autowired StudentApplicationService studentApplicationService;
  
  @Autowired StudentApplication studentApplication;
  
  @RequestMapping(path="addStudentApplication") public String
  addStudentApplicationPage() { return "STUDENT_APPLICATION"; }
  
  @RequestMapping(path="addStudentAppliaction.do",method=RequestMethod.POST)
  public String addStudentApplication(StudentApplication studentApplication){
  studentApplication.setStatus("Ongoing"); boolean result=
  studentApplicationService.addApplication(studentApplication);
  
  if(result) { return "STUDENT_HOME"; } else { return "ERROR"; } }
  
  }
 